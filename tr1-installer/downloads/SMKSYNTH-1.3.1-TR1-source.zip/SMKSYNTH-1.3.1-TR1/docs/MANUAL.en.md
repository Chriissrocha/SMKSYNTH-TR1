# SMKSYNTH 1.3.0 - Endless MIDI - Complete manual

[PDF](pdf/SMKSYNTH-1.3.0-Manual-EN.pdf) · [Português](MANUAL.md) · [English](MANUAL.en.md)

Reference: firmware 1.3.0, SMK-37 Pro_19664 / SMK-37 Elite_19664.

## Contents

- New in 1.3.0: SUB OSC and performance
- 1. Overview and navigation
- ENDLESS: record and perform
- MIDI MODE: independent controller
- MIDI MODE: bank B channels and layers
- Theme, oscilloscope and saving
- Battery and release identification
- 2. Buttons: reference
- 3. Performance, faders and wheels
- 4. Favourites and presets
- 5. Split and Layer
- 6. Patterns and scenes
- 7. DRUM-X and Drum Pads
- 8. Live and step recording
- 9. Sequencer: views and controls
- 10. Transpose and held commands
- 11. ANALOG: oscillators, filter and envelopes
- 12. LFO, arpeggiator, polyphony and output
- 13. Effects and mixer
- 14. GLOBAL and MIDI
- 15. Saving, installation and backup
- 16. Simulator, troubleshooting and reference
- SUPER / Supersaw
- MIDI OUT - USB and TRS/DIN
- Sustain and MIDI PANIC
- MIDI appendix / 1
- MIDI appendix / 2
- MIDI appendix / 3
- Updates and USB audio

## AI-assisted development

Developed using AI: Marcus Padrini defined and directed the experience, created the patterns and tested on hardware. ChatGPT (OpenAI) contributed technical solutions and generated and revised code, tools, documentation and graphics. Original engines: authors in CREDITS.md. No OpenAI endorsement.

## New in 1.3.0: SUB OSC and performance

Hardware-tested dual-core ANALOG engine. Each voice has a simple additive SUB OSC, without reducing OSC1/OSC2: PARA > OSC1 > OSC2 > SUB OSC. K1 WAVE (SQUARE/SAWTOOTH), K3 LEVEL (0-100%), K4 OCT (-1/-2). Follows OSC1 fundamental without component spread; shares filter and envelopes. Older patches start with SUB off. Supersaw remains OSC1-only.

K5 controls 40-240 BPM on every synth page. BPM is visible on Performance, scope, Split/Layer, Mixer, ARP and SEQ. MIDI MODE keeps configurable K5. In Split/Layer, < selects LEVEL and > OCT for K2/K3.

Saving/copying a pattern stores internal BPM. GLOBE > TEMPO SOURCE, K1: MASTER (default) keeps current tempo; PATTERN recalls saved BPM, including during playback changes. Older patterns without BPM keep current tempo. External MIDI clock takes priority. Source is saved automatically when stopped and quiet; pattern saving remains manual.

GLOBE > INITIALIZE: K1 chooses PART PATCH or PATTERN; PLAY opens review; K1 INITIALIZE and PLAY confirm. PATCH cancels. PLAY/PATCH have exclusive actions on this page. Initialized pattern: A/B/C INIT, D basic DRUM-X, equal levels, FX off, empty 16-step tracks and SINGLE. After execution: NOT SAVED for 2.2 s, then Performance. Nothing is saved until explicitly requested.

Zoom: patch/part names on Split/Layer, colored Mixer parts, persistent pad identity, SUB/SUPER voice meters and hold-REC clear feedback. ENDLESS READY means waiting for a key; progress follows selected part. First-record redraw and Master controls (volume, filter, drive and compressor) are fixed.

## 1. Overview and navigation

Firmware 1.3.0 for M-VAVE SMK-37 Pro / Elite. Four parts A-D; ANALOG (OberVave) or DRUM-X per part. Eight shared ANALOG voices. 16 patterns; up to 256 steps per track and four notes per ANALOG step.

![knobs](diagrams/knobs-en.svg)

K1-K4 edit the labels shown on screen. K6 selects part, K7 preset, K8 physical master. K5 controls tempo on every synth page, including ARP/SEQ and Mixer. It remains configurable in MIDI MODE.

Pad bank and display page are separate states. PLAY, REC and engine selection do not automatically choose another bank. SEQ explicitly requests steps; KNOB BANK returns to the manual cycle.

| Bank | Entry | Purpose |
| --- | --- | --- |
| 1 | KNOB BANK | Performance and eight favourites |
| 2 | KNOB BANK | Two Split/Layer rows |
| 3 | KNOB BANK | 16 patterns/scenes and save |
| 4 | KNOB BANK + DRUM-X | Play/record eight instruments |
| SEQ | SEQ | 16 steps in the page |

Tap = press and release. Hold = keep pressed for the stated time. Pad diagrams use two rows of eight, left to right: 1-8 above, 9-16 below. Other drawings are functional maps, not to scale.

## ENDLESS: record and perform

ENDLESS is included in official version 1.2. It works in SINGLE, with four parts and independent lengths. Turn Split/Layer off. DRUM-X keeps its drum sequencer. Opening the page does not enable ENDLESS.

1. Select a part with K6 and cycle SEQ views to ENDLESS. Tap PARA to enable; tap PARA again to disable without deleting notes. REC also enables it and starts note entry.
2. With transport stopped, tap REC and enter notes or chords: after releasing all keys, the next press appends a step. Up to 256 steps per part.
3. During entry, right arrow adds a rest with no keys held or extends held notes; left arrow removes the last step after keys are released. Tap REC again to finish entry.
4. With ENDLESS enabled, a key triggers/transposes the parts together: C4 keeps original pitch, independently of the part editing octave. PLAY starts or stops transport. K4 HOLD keeps playback going after keys are released; with HOLD off, releasing the last key stops the session.
5. K1 RATE, K2 GATE, K3 DIR (FWD/REV/RND), K4 HOLD. Save in the pattern bank to retain sequences, sounds and settings.
6. Holding REC for over 1.2 s clears the selected part sequence and automation. Stopping, leaving the page or disabling ENDLESS does not delete recorded notes.

ENDLESS sends notes through USB and TRS/DIN using each part channel, like the regular sequencer. It does not send MIDI Clock/Start/Stop.

## MIDI MODE: independent controller

In MIDI MODE the synthesizer is silent and controls send MIDI through USB and TRS/DIN. Bluetooth is not included. Entering and leaving release notes and clear temporary modulation to preserve the patch on return to the synth.

1. In the synth, cycle GLOBE to MIDI MODE. Before activation the page shows only the entry control; turn K1 right.
2. In MIDI MODE, GLOBE opens settings: K1 left returns to the synth; K2 selects MAP 1-4; K3 sets main channel 1-16; K4 selects ABS or REL encoders. This channel is independent of the synth part base channel.
3. KNOB BANK and FADER BANK switch banks A/B. Press both together to switch pad bank. OCT-/+ transpose the keyboard.
4. Tap PARA to edit. Move the desired control or use K5/OCT to select it. K1 selects an allowed type (OFF, CC, CC TOGGLE, NOTE or PITCH BEND), K2 the CC/note number, K3 channel (MAIN or 1-16), and K4 bank A pad colour. Bank B is reserved for keyboard channels and cannot be edited. Wheels follow keyboard channels (KEYS). Available types depend on the control.
5. BT saves all four maps, including configured channels, colours and behaviour. The temporary bank B selection is not saved. Release keys, pads and pedal before saving. PARA returns to the performance overview. ABS encoders accelerate with turning speed; REL uses relative messages.
6. The display keeps three independent areas: last controller value and bars, pads with activity, and a 37-key virtual keyboard showing chords. GLOBE + PLAY triggers MIDI PANIC.

The simulator demonstrates the interface and retains browser memory; it does not replace physical USB/TRS port testing. A .smksynth backup stores the synth bank; MIDI maps and theme use separate memory and are not included in that file.

## MIDI MODE: bank B channels and layers

This bank belongs only to MIDI MODE, which replaces the synth while active. Synth performance, Split/Layer and pattern banks keep their existing functions. ENDLESS still sends MIDI on each synth part channel, independently of controller bank B.

1. Enter MIDI MODE. Press KNOB BANK + FADER BANK together until CHANNELS / bank B appears.
2. Tap and release one pad alone: pad 1 selects channel 1, pad 3 channel 3, through pad 16 / channel 16. The keyboard then transmits on that channel. Bank B pads send neither notes nor CCs.
3. To create a layer, hold one pad while pressing the other desired channels. Example: hold 1, press 3 and 6, then release all pads. The keyboard transmits on channels 1, 3 and 6. Illuminated pads show the selection.
4. The selection remains after releasing pads and returning to bank A. A new single-pad gesture replaces the whole layer with that channel. No need to deselect previous channels.

| Source | Destination in MIDI MODE |
| --- | --- |
| Keyboard, pitch bend, mod wheel and sustain | All selected channels; USB and TRS/DIN. |
| Encoders, faders and bank A pads | Configured map channels; independent of the layer. |
| Previously held notes | Note Off retains original channels and pitches after changing layer or octave. |

Sustain release also reaches previously used channels. Entering MIDI MODE, switching MAP or changing main channel resets selection to that map main channel (default: 1). Bank B selection is temporary. Previous bank B pad mappings remain stored but inactive in this release.

## Theme, oscilloscope and saving

GLOBE > THEME: K1 selects OBERVAVE (default) or ZOOM. The preference saves automatically after 1.5 s with transport stopped and audio quiet. No preset save is needed. Theme saving does not commit pending MIDI map edits.

Zoom uses larger labels and values. Part colour identifies the header line, part badge (white letter), and preset number. Text, values and grid retain the instrument palette. The pattern number stays visible in performance.

Performance values are the default view. A short PATCH opens the logo, overall-output oscilloscope and voices/drum pieces; another tap enters the Mixer cycle. A long PATCH returns to values. The oscilloscope keeps fixed colours and has no pattern indicator. Edits appear in a Zoom notice for about one second, then disappear.

| Flow | Screens and commands |
| --- | --- |
| Quick save | Short BT saves the sound to its current slot, retaining the name. |
| Save as / rename | Long BT opens editing. K1 moves cursor; K2 chooses character (up to 10); K7 selects slot 01-99. The screen shows the program already in the destination. |
| Review replacement | BT opens the name/destination review, showing the program to be replaced. Release and press BT again to write. |
| Back / cancel | PATCH from review returns to editing; PATCH from editing cancels without writing. |

## Battery and release identification

Endless MIDI is this public edition name. The bottom of the splash shows its name and technical version 1.3.0. To check later, cycle GLOBE to THEME: that page also shows ENDLESS MIDI and the technical version in either theme. The technical number is updated for every release build.

A discreet battery meter appears in Obervave and Zoom headers, the oscilloscope, ENDLESS view and MIDI MODE performance. It uses the existing instrument reading, filtered to avoid fluctuations. It does not change audio or write settings.

| Indicator | Meaning |
| --- | --- |
| 1 to 4 bars | Approximate charge bands, not a percentage. |
| Lowest band in red | Low battery; connect power. |
| Grey outline without bars | Reading unavailable or still settling; does not mean full. |

The meter does not detect charging or guarantee remaining runtime. Allow a few seconds for its initial reading to settle. Connecting USB does not automatically turn the icon into a full battery.

## 2. Buttons: reference

![buttons](diagrams/buttons-en.svg)

| Button | Function |
| --- | --- |
| PATCH | Tap: Performance; on Performance opens the oscilloscope; the next tap opens Mixer; in Mixer cycles seven rows. Hold 0.7 s: return to Performance. |
| PARA | Tap: synthesis pages; in STEPS clears and advances a step (DRUM: clears the lane hit). Hold: edit/erase layer. |
| CHORD | ANALOG: FILTER ENV / AMP ENV. DRUM-X: DRUM SOUND. |
| NOTE REPEAT | ANALOG: LFO / LFO DEST / LFO +. DRUM-X redirects to DRUM SOUND. |
| ARP | Open ARP. Another tap on that page toggles the part’s HOLD. |
| SCALE | Hold in ANALOG STEPS: STEP+. On GLOBAL, tap toggles SYNC AUTO / INTERNAL. |
| GLOBE | Tap: GLOBAL > TEMPO SOURCE > POLYPHONY > OUTPUT > PART SETUP > CONTROLS > THEME > MIDI MODE > INITIALIZE. Hold: keys for start/stop, mute, solo and tap tempo. |
| BT / SAVE | Tap: save the part preset to its current program. Hold 0.7 s: SAVE PRESET AS; K1 moves the cursor, K2 changes the character and K7 chooses destination. BT reviews; a second BT confirms. |
| FX | Tap: CHORUS > DELAY > REVERB > DRIVE. Hold: K1/K2/K3 chorus/delay/reverb returns; K4 delay time. |
| SEQ | Tap: sequencer views and explicit step-pad ownership. Hold: white keys become steps. |
| PLAY | Start from step 1 or stop. Stopping also ends REC. |
| REC | Tap: arm while stopped; toggle recording while running. Hold over 1.2 s: clear selected track. |
| KNOB BANK | Tap: cycle pad banks. Hold 0.7 s: Performance/Favourites. From SEQ, one tap returns to Performance. |
| FADER BANK | Toggle fader bank A / B; lit LED means B. Does not change the pad bank. |
| OCT - / + | Selected part octave: -2 to +2; both together reset. While holding SEQ: page; while holding PARA: undo/redo. |
| < / > | 16-step page for the selected track, within its configured length. |

## 3. Performance, faders and wheels

![performance](diagrams/performance-en.svg)

|  | K1 | K2 | K3 | K4 |
| --- | --- | --- | --- | --- |
| ANALOG | CUTOFF | RESO | ENV AMT | RELEASE |
| DRUM-X | MORPH | TONE | DECAY | FOLD |
| KEY TRANS ON | Normal | Normal | Normal | KEY TR |

Pads 1-4 select A-D. Pads 5/6 disable or restore the part’s delay/reverb sends. Pads 7/8 change preset. When KEY TRANS is enabled, K4 shows KEY TR instead of Release/Fold; turn left to disable capture.

![faders](diagrams/faders-en.svg)

Fader Bank A controls the selected part on every page. Bank B: F1-F3 are per-part sends. GLOBAL > FADER MODE selects JUMP (immediate) or CATCH (engages when crossing the stored value). F4 and K8 control the same physical master. This differs from VOL on the Mixer MASTER row.

Physical Pitch and Mod follow the selected part. Pitch uses the sound’s BEND range; Mod adds vibrato. Held notes retain their correct note-offs when changing parts.

## 4. Favourites and presets

![performance](diagrams/performance-en.svg)

1. Select a part with K6 or pad 1-4 and adjust the sound.
2. To store, hold one of pads 9-16 for 0.7 s.
3. Stop PLAY/REC, release notes and sustain, and wait for FAVOURITES SAVED.
4. To recall, tap a favourite. It loads into the selected part, not the original source part.

Each favourite stores a sound snapshot, program number, edited state, patch octave and chorus/delay/reverb sends. Shared effect returns and tails are preserved on recall. Saving an extra preset first is not required.

| Operation | Command | Result |
| --- | --- | --- |
| Save preset | BT / SAVE | Overwrite the part’s current program |
| Save preset as | Hold BT; K1/K2/K7; BT; BT | Name and choose one of 99 programs; review before overwrite |
| Cancel Save As | PATCH | Close without confirming the write |

The base has 64 factory presets and INIT positions 65-99. A user save can overlay any position. A preset does not contain the entire sequence or all four parts. Wait for PRESET SAVED / SETTINGS SAVED before powering off; writing waits for stop and silence if playing.

## 5. Split and Layer

![split](diagrams/split-en.svg)

The two rows are independent configurations. A-D select ANALOG parts. Hold one part and press another in the same row to create the pair/layer. SINGLE uses the normal selected-part flow; SPLIT divides the keyboard; LAYER plays both parts. DRUM-X cannot be used in these combinations.

|  | K1 | K2 | K3 | K4 |
| --- | --- | --- | --- | --- |
| LEVEL | MODE | Part 1 level | Part 2 level | SPLIT |
| OCT | MODE | Part 1 octave | Part 2 octave | SPLIT |

1. Enter bank 2 using KNOB BANK.
2. In the desired row, form the pair using two A-D pads.
3. Tap SPLIT or LAYER; adjust the split point with K4.
4. < selects LEVEL (0-100%); > selects OCT (-2 to +2) for K2/K3. K5 controls tempo.
5. Tap PLAY 1 (pad 8) or PLAY 2 (pad 16) to play that configuration.
6. Save the pattern to store both rows and the active row.

Bright white pad 8/16 identifies the playing row. Editing the other row does not activate it. K6 still selects the recording part; that part must be in the heard routing to record. In SPLIT, notes below the split belong to the first part; at and above it, to the second.

## 6. Patterns and scenes

![patterns](diagrams/patterns-en.svg)

Each slot combines a four-track sequence and its scene: four sounds, mix and Split/Layer configurations. Favourites are a separate bank. Saving/copying a pattern stores current internal BPM. GLOBE > TEMPO SOURCE: MASTER keeps current tempo across changes; PATTERN recalls stored BPM. Older patterns without BPM retain current tempo.

| Gesture | Action |
| --- | --- |
| Tap P1-P16 | Load when stopped; schedule for the next bar while playing |
| Hold 0.7 s | Save the current pattern to that slot; another slot acts as a copy |
| Occupied slot | OVERWRITE: tap the same pad within 4 s to confirm |
| Other pad / PATCH / timeout | Cancel overwrite confirmation |

Writing waits for stop and silence. If STOP TO FINISH SAVE FIRST appears, finish the previous save before changing/copying. Navigating does not automatically save edits; save before loading another pattern.

| Light | Meaning |
| --- | --- |
| Very dim red | Empty slot |
| Red | Occupied slot |
| Blue | Selected pattern; intensity changes when edited |
| Blinking blue | Scheduled change |
| Blinking red | Overwrite confirmation |
| Bright white | Pending write to that slot |

Initial content: P1-P5 filled; P6-P16 empty; eight favourites; 90 BPM; no extra personal presets. Restoring your backup replaces this content with the file’s data.

## 7. DRUM-X and Drum Pads

![drums](diagrams/drums-en.svg)

1. Select the part with K6. Tap GLOBE until PART SETUP.
2. K1 selects DRUM-X; K2 chooses 808 BOOM, 909 CLUB, 606 MINI, 707 SNAP or DRUM-X.
3. Cycle KNOB BANK to Drum Pads. Selecting a kit alone does not change the bank.
4. Play the upper pads with velocity. PLAY/REC preserve the chosen bank.
5. To record live, start PLAY, tap REC and play the pads; REC ends recording, PLAY stops everything.

Drum Pads only enters the cycle when a DRUM-X part is selected. If you select ANALOG while this bank is active, it remains selected but inactive; use K6 to return to DRUM-X or KNOB BANK to leave. Pads 9-16 are reserved/unlit.

Violet at about 70% at rest; white on live hits and sequenced notes. Each instrument can retrigger; open/closed hi-hats choke each other. 606/707 kits are timbral starting points, not ROM reproductions.

|  | K1 | K2 | K3 | K4 |
| --- | --- | --- | --- | --- |
| PERFORM | MORPH | TONE | DECAY | FOLD |
| DRUM SOUND | SOUND | LEVEL | DECAY | PITCH |
| PART SETUP | ENGINE | KIT | VOLUME | TUNE |

| Instrument | KICK | SNARE | CLAP | HAT CL | HAT OP | TOM | RIM | BELL |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| MIDI | 36 | 38 | 39 | 42 | 46 | 45 | 37 | 56 |

MIDI notes 60-67 also trigger the eight lanes in order. In DRUM SEQ, multiple hits can share a step; velocity, ratchet, chance and nudge belong to the step and affect its hits.

## 8. Live and step recording

| Mode | Preparation | Record / stop |
| --- | --- | --- |
| Live | PLAY > REC | Play keys/pads; REC ends recording, PLAY stops |
| Arm while stopped | REC | First note starts recording; REC then PLAY can use count-in |
| ANALOG step entry | PLAY stopped; REC off; SEQ > STEPS | Play note/chord; release all keys to advance |
| DRUM-X grid | SEQ > DRUM; REC off | K1 chooses lane; pads toggle hits in 16 steps |

K6 selects the recording track. Length 0 disables the track; use TRACKS K3 to give it a length (initially 16). Recording quantize is per part: TRACKS K4 = OFF, 1/32, 1/16, 1/8 or 1/4. Live recording can retain microtiming; step entry resets the rewritten step’s nudge.

1. To create an ANALOG example, choose an empty slot and part A.
2. Open SEQ > TRACKS and set LENGTH to 16.
3. Go to STEPS with REC off. Play a chord, release, repeat.
4. For a rest, leave the step empty and advance K1. PARA clears the step.
5. For a long note, hold the keys and advance K1 to tie into the next step.
6. Press PLAY to listen. Stop, enter Patterns and hold the slot to save.

Recording accounts for physical patch octaves and Split/Layer octaves. In Split/Layer, only notes routed to the K6-selected part are recorded. With ARP enabled, recording captures the arpeggiator output rather than its input chord.

Automation: with PLAY/REC active and the track on, turning an eligible parameter knob records its value at the playing step. Up to four parameters per track. Shared effect parameters, faders and navigation are not recorded through this path. Automation is saved with the pattern; holding REC to clear a track also clears its automation.

To clear an entire track, select it with K6 and hold REC over 1.2 s. This command has no second confirmation. PARA + OCT- undoes and PARA + OCT+ redoes the available edit (one level).

## 9. Sequencer: views and controls

![steps](diagrams/steps-en.svg)

|  | K1 | K2 | K3 | K4 |
| --- | --- | --- | --- | --- |
| TRACKS | CUTOFF / MORPH | LEVEL | LENGTH | QUANT |
| STEPS | STEP | NOTE | GATE | VELO |
| STEP+ | STEP | RATCHET | CHANCE | ON/OFF |
| TRACK | LENGTH | DIV | SWING | TRANSP |
| PATTERNS | SLOT | - | GO: turn + | Use pads |
| TRANSPOSE | KEYS | VALUE | RESET | ANALOG: display |
| DRUM | SOUND | STEP | VELO | RATCHET |
| DRUM+ | SOUND | CHANCE | NUDGE | ON/OFF |

Tap SEQ to cycle views. ANALOG: TRACKS > STEPS > TRACK > PATTERNS > TRANSPOSE. Hold SCALE in STEPS for STEP+. DRUM-X: DRUM > DRUM+ > TRACK > TRACKS > PATTERNS > TRANSPOSE.

K5 controls tempo in STEPS/DRUM and all other SEQ views. Arrows < > change pad pages; Pattern bank pads select patterns. K6 always selects part; K7 changes its preset; K8 master. A track supports up to 256 steps in 16 pages; its DIV is independent. SWING ranges from 50 to 75%; per-track TRANSP from -24 to +24 semitones.

RATCHET: 1x-4x; CHANCE: 0-100% in 5% increments; ON/OFF disables without deleting notes. GATE reaches TIE. NOTE shifts the step chord. In the DRUM grid, K1 selects the lane and each pad toggles a hit in that lane; this is not the Drum Pads bank.

## 10. Transpose and held commands

|  | K1 | K2 | K3 | K4 |
| --- | --- | --- | --- | --- |
| SEQ TRANSPOSE | Capture ON/OFF | Offset -48..+79 | Zero offset | ANALOG |
| SEQ held | Input note | DIV | SWING | LENGTH |
| Held step | NOTE | LEVEL | RATCHET | GATE |
| PARA held | SHIFT | Length x2 / half | TRANSPOSE | - |
| FX held | CHO MIX | DLY MIX | REV MIX | DLY TIME |

In SEQ > TRANSPOSE, K1 enables keyboard capture. The offset affects ANALOG sequences, not the fixed drum map. It remains active after leaving the screen or changing pad banks. Performance K4 KEY TR disables capture; the current offset remains until K3 RESET on TRANSPOSE.

Hold SEQ with REC off: 16 white keys F3-G5 control steps; black keys F#3-A#4 select the first eight pages. OCT-/+ also changes pages. An empty step receives the last note/chord; tapping and releasing a filled step clears it. Hold to edit with knobs; hold one step and tap a later one for a long note.

Hold PARA: keys erase that note from track steps. K1 rotates the sequence; K2 doubles/halves length; K3 transposes ANALOG notes. In DRUM-X, K3 reports DRUM MAP FIXED. OCT- undoes and OCT+ redoes.

Hold SEQ/PARA/GLOBE/FX and tap PATCH to latch the command without continuing to hold. Tap the same button to unlatch. This temporary command layer is different from the two-part LAYER mode.

![globalkeys](diagrams/globalkeys-en.svg)

Hold GLOBE: F3/G3/A3/B3 start/stop tracks A-D on the bar (with REC active, select recording); C4/D4/E4/F4 toggle mute; G4/A4/B4/C5 toggle solo; G5 is tap tempo. Pads retain their chosen bank.

## 11. ANALOG: oscillators, filter and envelopes

PARA cycles OSC 1, OSC 2, OSC MOD, FILTER, FILTER + and SUPER. CHORD alternates FILTER ENV and AMP ENV. Four knobs follow the columns below; pads retain the manual bank and faders retain Bank A/B.

|  | K1 | K2 | K3 | K4 |
| --- | --- | --- | --- | --- |
| OSC 1 | WAVE | PW | LEVEL | NOISE |
| OSC 2 | WAVE | PW | LEVEL | SEMI |
| OSC MOD | SYNC | X-MOD | ENV>O2 | FINE |
| FILTER | RESO | ENV AMT | KEY TRK | TYPE |
| SUPER | DETUNE | MIX | -- | -- |
| FILTER + | DRIVE | VEL>FLT | VEL>AMP | MORPH |
| FILTER ENV | ATTACK | DECAY | SUSTAIN | RELEASE |
| AMP ENV | ATTACK | DECAY | SUSTAIN | RELEASE |

| Group | Use |
| --- | --- |
| OSC 1/2 | WAVE: OFF, SAW, PULSE, SAW+PLS; SUPER is exclusive to OSC 1; PW controls pulse width or DETUNE in SUPER. LEVEL mixes each oscillator; NOISE adds noise. SEMI tunes OSC2 from -24 to +24 semitones; FINE is fine tuning. |
| OSC MOD | SYNC synchronizes oscillators; X-MOD controls cross modulation; ENV>O2 applies envelope to OSC2 pitch (bipolar). |
| FILTER | CUTOFF is on Performance/fader A1; RESO emphasizes cutoff. ENV AMT is bipolar. KEY TRK follows pitch. TYPE: LP12, HP12, BP12, NOTCH, LP24, SEM; MORPH changes SEM. |
| ENVELOPES | ATTACK: onset; DECAY: fall to SUSTAIN; RELEASE: tail after release. FILTER ENV shapes filtering; AMP ENV shapes amplitude. VEL>FLT/VEL>AMP set velocity response. |

Parameters without a physical unit use the internal 0-127 scale. Displayed times and frequencies are firmware conversions; one raw increment does not always equal a fixed ms/Hz increment.

## 12. LFO, arpeggiator, polyphony and output

|  | K1 | K2 | K3 | K4 |
| --- | --- | --- | --- | --- |
| LFO | SHAPE | RATE | DELAY | PHASE |
| LFO DEST | PITCH | PWM | FILTER | AMP |
| LFO + | PITCH> | PWM> | - | - |
| ARP | ARP | DIV | OCTAVES | GATE |
| POLYPHONY | MODE | VOICES | DETUNE | GLIDE |
| OUTPUT | VINTAGE | SPREAD | BEND | VOLUME |
| PART SETUP | ENGINE | KIT | MODE | GLIDE |

NOTE REPEAT cycles LFO / LFO DEST / LFO +. SHAPE: TRI, SAW, RAMP, SQUARE, S&H, RANDOM. PHASE: SYNC, FREE, SPREAD. PITCH/PWM targets select OSC1, OSC2 or BOTH. PITCH, PWM, FILTER and AMP depths are independent.

ARP opens its page. Modes OFF, UP, DOWN, UP/DN, RANDOM and PLAYED. DIV: 1/4, 1/8, 1/8T, 1/16, 1/16T, 1/32, 1/32T. OCTAVES ranges from 0 to 4 on the firmware scale. GATE controls duration. Tap ARP again to toggle part HOLD, keeping notes after release. Disable HOLD/ARP to end.

GLOBE cycles GLOBAL, POLYPHONY, OUTPUT and PART SETUP. ANALOG: MODE selects POLY, DUAL, UNISON or MONO. VOICES and DETUNE configure unison; GLIDE controls portamento. Eight ANALOG voices are shared among parts; unison consumes more voices per note.

ANALOG OUTPUT: VINTAGE adds variation, SPREAD stereo distribution, BEND pitch range in semitones (0-24), VOLUME patch level. PART SETUP: K1 chooses engine; K2 only selects KIT in DRUM-X. In DRUM-X, POLYPHONY becomes MORPH/TONE/DECAY/FOLD macros; OUTPUT uses K1 VOLUME and K2 TUNE, with no K3/K4.

## 13. Effects and mixer

![faders](diagrams/faders-en.svg)

|  | K1 | K2 | K3 | K4 |
| --- | --- | --- | --- | --- |
| CHORUS | RATE | DEPTH | MIX | - |
| DELAY | TIME | FEEDBK | TONE | MIX |
| REVERB | SIZE | DAMP | PRE-DLY | MIX |
| DRIVE | TYPE | DRIVE | TONE | MIX |
| Mixer: LEVEL/PAN/SEND | A | B | C | D |
| Mixer: MASTER | VOL | DJ FLT | DRIVE | COMP |

FX cycles four effect pages. Effects are shared: MIX sets the global return; send controls how much each part feeds the effect. To change one part’s amount, use Bank B F1/F2/F3 or the Mixer SEND row. A zero MIX return can make an effect inaudible even with a high send.

DELAY TIME uses synced divisions: 1/16, 1/8T, 1/8, dotted 1/8, 1/4, dotted 1/4 and 1/2. FEEDBK sets repeats; TONE darkens/brightens them. REVERB: SIZE room size, DAMP damping, PRE-DLY initial delay. CHORUS: RATE speed, DEPTH intensity.

From Performance, tap PATCH for the oscilloscope; tap again to open Mixer. Further taps cycle LEVEL > PAN > SEND CHORUS > SEND DELAY > SEND REVERB > SEND DRIVE > MASTER. K1-K4 adjust A-D on the first six rows. On MASTER, VOL/DJ FLT/DRIVE/COMP are global mixer controls. K5 controls tempo; hold PATCH to leave.

Per-part mute and solo: hold GLOBE and use the corresponding keys. The Mixer displays their states. Bank B F4 and K8 are physical output volume, not four individual part volumes.

## 14. GLOBAL and MIDI

|  | K1 | K2 | K3 | K4 |
| --- | --- | --- | --- | --- |
| GLOBAL | TEMPO | CLICK | MIDI CH | TUNE |

TEMPO: 40-240 BPM. CLICK: OFF, REC, ON or COUNT-IN. With COUNT-IN, arm REC while stopped and use PLAY for the count. MIDI CH: OMNI or base channel 1-13. TUNE: -50 to +50 cents. On GLOBAL, SCALE toggles SYNC AUTO / INTERNAL.

| Message | Behaviour |
| --- | --- |
| Notes / velocity | Base channel routes to A; next three channels to B-D. OMNI uses the selected part. For four complete channels, choose base 1-13. |
| Program Change | 0-98 select programs 1-99. In OMNI affects the selected part; with defined channels, the addressed part. |
| CC 7 / CC 64 | MIDI volume / sustain (64 or above = pedal on). |
| CC 120 / 123 | Panic / stop notes. |
| Pitch Bend / CC 1 | MIDI pitch and modulation depth; physical wheels follow the selected part. |
| Clock / Start / Continue / Stop | AUTO accepts incoming MIDI clock/transport; INTERNAL ignores those messages. |

Incoming MIDI notes are absolute: do not treat them as local keys receiving the SMK physical octave. USB/TRS MIDI output transmits all four parts: A uses the base channel; B-D the next channels. OMNI transmits on 1-4. Keys, pads, Split/Layer, ARP and sequencers send notes with their octaves and transpositions. MIDI Clock/Start/Stop output is not included.

The appendix lists ANALOG parameter CCs. DRUM-X reuses several internal addresses for macros/lanes; use the DRUM interface for editing and the section 7 note map for triggering drums.

## 15. Saving, installation and backup

| What to save | Command | Contents |
| --- | --- | --- |
| Preset | BT / SAVE | One sound/program; not the four-part sequence |
| Favourite | Hold F1-F8 pad | Part snapshot and sends |
| Pattern/scene | Hold P1-P16 | Sequences, sounds, mix, two Split/Layer rows |
| Full backup | Web tool | Saved bank: presets, favourites, patterns/scenes and globals |

Saving is manual: an on-screen edit is not a flash write. Stop transport, release notes/sustain and wait for completion. Pending pattern/preset saves block conflicting operations. Export only after saving on the instrument.

1. For first installation, start from your Pro or Elite model’s official M-VAVE V016 firmware. Use official M-UPGRADE to return to that version.
2. Export your .smksynth before returning to stock. First installation initializes/replaces the bank.
3. Use Chrome/Edge on a computer, HTTPS, a USB data cable and stable power. Close other MIDI applications.
4. In the web installer, connect, check source/target and confirm. Wait for SMK-37 Pro_19664 / SMK-37 Elite_19664.
5. If interrupted, resume in the same browser/site using the same package. Do not change installer midway.

Backup: stop PLAY/REC, release controls/notes and connect the tool. Export the current bank in this session before restoring. Choose the file, review and type RESTAURAR (also in the English interface). Restoration replaces the whole bank; it does not merge. On completion, reboot and check your sounds.

RESTORE PENDING: resume with the same file; the instrument remains locked until completion. Official firmware cannot import .smksynth. After reinstalling SMKSYNTH, restore your bank through the browser. Marcus confirmed physical installation on hardware; automated logs document the other tests.

## 16. Simulator, troubleshooting and reference

The simulator runs audio/interface code in WebAssembly. Click Start; on HTTPS this gesture activates audio. Use mouse/touch, drag knobs vertically and adjust velocity. Computer keys A W S E D F T G Y H U J K O L P ; play notes.

Memory is local to the browser/domain. Panel SAVE writes to that memory. Export session saves a simulator JSON file; Import session replaces that memory. This JSON is not a physical .smksynth backup. Restart does not erase the session; Replay boot reruns startup.

| Symptom | Check |
| --- | --- |
| No sound | K8/master, part/Mixer level, mute/solo, engine and Split routing. In simulator: Start, browser audio and Mute. |
| Pads do not play drums | Select a DRUM-X part, then Drum Pads using KNOB BANK. Kit selection does not change the bank. |
| Send fader does not respond | Bank B and correct part; cross stored value for pickup. Check effect MIX return. |
| Keys only transpose | KEY TRANS enabled; disable via SEQ > TRANSPOSE K1 or Performance K4 KEY TR. Zero offset with K3 RESET if needed. |
| Notes do not record | Nonzero LENGTH, K6 on correct part, Split routing and correct REC/step entry mode. |
| Save does not finish | Stop PLAY/REC, release notes/sustain and wait for silence. Do not power off during writing. |
| Export session expired | Stop everything, wait for saves, reboot and reconnect before exporting again. An incomplete file is not a valid backup. |
| Installer rejects firmware | First installation requires the connected Pro or Elite model’s V016; other sources are blocked. |

Independent project. ANALOG synthesis: OberVave/zvenson; DRUM-X: JIANT; SUPER: originated in Clipper/3dSam (github.com/isod89/clipper-fm1); SMKSYNTH direction and hardware tests: Marcus Padrini; technical solutions, adaptation code and documentation with ChatGPT (OpenAI), under his direction. See repository CREDITS.md and LICENSING.md for all attributions. GPL-3.0-only.

## SUPER / Supersaw

Select WAVE = SUPER only on OSC 1. To preserve stability, OSC 2 does not offer SUPER. OSC 1 mixes seven saws: one central and six detuned. PW becomes DETUNE. LEVEL still sets oscillator volume.

PARA cycles OSC 1 > OSC 2 > OSC MOD > FILTER > FILTER + > SUPER. On the SUPER page the four knobs control:

| K1 | K2 | K3 | K4 |
| --- | --- | --- | --- |
| DETUNE | MIX | -- | -- |

DETUNE (0-127): OSC 1 detune spread. MIX (0-127): level of the six side saws relative to the central saw; MIX 0 keeps only the central saw. Default MIX is 64.

Start with one SUPER oscillator, moderate DETUNE and MIX 64. Add OSC2 and effects as needed. OSC2 SEMI/FINE, pitch bend, glide, vibrato, envelopes and filters remain available. Eight ANALOG voices are shared; while SUPER is in use, allocation is limited to five voices and prioritizes replacing release tails. Seven saws do not add polyphony. UNISON stacks complete voices and increases load.

When either oscillator uses SUPER, SYNC and X-MOD are bypassed. PWM does not modulate SUPER detune. DETUNE uses the existing PW CCs and automation; MIX has no dedicated CC or automation.

Settings are saved in presets, favourites, scenes and backups. Older sounds open without conversion, using MIX 64. Before returning to firmware predating SUPER, restore a backup made with that version: it does not understand WAVE 4 or all new favourites.

P displays peak processing time in microseconds; O counts blocks exceeding their deadline. Both reset at boot. Marcus approved this release base on hardware; load depends on polyphony, unison and effects.

Origin: Clipper, by 3dSam, built on Felucca, with the detune curve and offsets derived from Adam Szabo’s analysis cited by Clipper. Source: https://github.com/isod89/clipper-fm1 . SMKSYNTH adapts this foundation with independent MIX and its own optimizations; it is not an exact Roland JP-8000/JP-8080 reproduction. GPL-3.0-only; attribution in CREDITS.md and LICENSING.md.

## MIDI OUT - USB and TRS/DIN

MIDI output transmits all four parts, independently of panel focus. GLOBAL > MIDI CH sets A’s base channel (1-13). B, C and D use base +1, +2 and +3. OMNI input uses output channels 1-4.

| Part | Output channel | Example: base 3 |
| --- | --- | --- |
| A / 1 | BASE | 3 |
| B / 2 | BASE + 1 | 4 |
| C / 3 | BASE + 2 | 5 |
| D / 4 | BASE + 3 | 6 |

USB and TRS receive the same musical messages. Keys, pads, Split/Layer, arpeggios and sequencers transmit notes. DRUM-X uses its part channel, with no mandatory channel 10. Split/Layer transmits each part’s actual notes and octaves. Every Note Off retains the destination of its original Note On.

Connect 3.5 mm MIDI OUT to the destination’s MIDI IN using the keyboard’s appropriate TRS-DIN adapter. Audio uses a separate jack. TRS works on battery without a computer; USB requires a MIDI host.

Pitch Bend is sent in 14 bits (centre 8192); the mod wheel uses CC1 (0-127). Both follow only the selected part, including Split/Layer, matching the local engine. Changing focus neutralizes the previous channel. Wheel state is resent after Panic.

MIDI Clock/Start/Stop output and automatic Program Change on internal preset selection are not included. Received notes are not simple MIDI Thru; generated arpeggios can transmit. Incoming bend remains global on the base channel, inherited from the engine; this differs from per-part output.

## Sustain and MIDI PANIC

### Sustain pedal

1. Connect the pedal before power-on and keep it released during startup.
2. Switch-pedal polarity is detected at startup. No half-pedal support; restart after changing pedals.
3. Press the pedal, play and release a chord: it continues until the pedal is released. Sustain applies to the four melodic parts, including Split/Layer and ARP. DRUM-X keeps its internal one-shot behaviour.
4. CC64 is sent to the four part channels and notes still held on previous channels. Pedal-up releases those channels. Physical and received MIDI sustain are independently combined.

### Panic: GLOBE + PLAY

Press GLOBE and PLAY together in either order. This stops PLAY/REC, clears HOLD/sustain and pending notes, and cuts internal voices. USB and TRS send CC64=0, CC123=0 and CC120=0 on all 16 channels. Release the pedal before using sustain again. Effect tails may finish normally.

1.3.0 also fixes stuck voices when changing POLY/DUAL to MONO/UNISON with keys held. Note Off already arrived, but old-mode voices could remain gated. Glide is unchanged; editing only Glide did not reproduce the failure in tests.

## MIDI appendix / 1

Incoming CC values are 0-127 and scaled to the parameter maximum. This table describes the ANALOG engine. Identifiers retain source names to distinguish oscillators/envelopes.

| ID | CC | Display | Raw maximum |
| --- | --- | --- | --- |
| O1_WAVE | 20 | WAVE | NWAVE - 1 |
| O1_PW | 21 | PW | 127 |
| O1_LVL | 22 | LEVEL | 127 |
| NOISE | 23 | NOISE | 127 |
| O2_WAVE | 24 | WAVE | NWAVE - 1 |
| O2_PW | 25 | PW | 127 |
| O2_LVL | 26 | LEVEL | 127 |
| O2_SEMI | 27 | SEMI | 48 |
| SYNC | 28 | SYNC | 1 |
| XMOD | 29 | X-MOD | 127 |
| ENV_O2 | 30 | ENV>O2 | 127 |
| O2_FINE | 31 | FINE | 127 |
| CUTOFF | 74 | CUTOFF | 127 |
| RESO | 71 | RESO | 127 |
| FENV_AMT | 32 | ENV AMT | 127 |
| KEYTRK | 33 | KEY TRK | 127 |
| FTYPE | 34 | TYPE | NFTYPE - 1 |
| DRIVE | 35 | DRIVE | 127 |
| VEL_FLT | 36 | VEL>FLT | 127 |
| VEL_AMP | 37 | VEL>AMP | 127 |
| FA | 38 | ATTACK | 127 |
| FD | 39 | DECAY | 127 |
| FS | 40 | SUSTAIN | 127 |
| FR | 41 | RELEASE | 127 |

Constants: NFTYPE-1 = 5; NDDIV-1 = 6. WAVE 0-4; MODE 0-3; SHAPE 0-5. For pages and four-knob assignments, see sections 11-14. Effect CCs are shared; they are not Bank B per-part sends.

## MIDI appendix / 2

Incoming CC values are 0-127 and scaled to the parameter maximum. This table describes the ANALOG engine. Identifiers retain source names to distinguish oscillators/envelopes.

| ID | CC | Display | Raw maximum |
| --- | --- | --- | --- |
| AA | 73 | ATTACK | 127 |
| AD | 42 | DECAY | 127 |
| AS | 43 | SUSTAIN | 127 |
| AR | 72 | RELEASE | 127 |
| LFO_SHAPE | 44 | SHAPE | 5 |
| LFO_RATE | 45 | RATE | 127 |
| LFO_DELAY | 46 | DELAY | 127 |
| LFO_PHASE | 47 | PHASE | 2 |
| LFO_PITCH | 48 | PITCH | 127 |
| LFO_PWM | 49 | PWM | 127 |
| LFO_FLT | 50 | FILTER | 127 |
| LFO_AMP | 51 | AMP | 127 |
| LFO_PITCH_TO | 52 | PITCH> | 2 |
| LFO_PWM_TO | 53 | PWM> | 2 |
| MODE | 54 | MODE | 3 |
| UNI_N | 55 | VOICES | 8 |
| UNI_DET | 56 | DETUNE | 127 |
| GLIDE | 5 | GLIDE | 127 |
| VINTAGE | 57 | VINTAGE | 127 |
| SPREAD | 58 | SPREAD | 127 |
| BEND | 59 | BEND | 24 |
| VOLUME | 60 | VOLUME | 127 |
| MOD_DEPTH | 1 | MOD DPT | 127 |
| ARP_MODE | 61 | ARP | 5 |

Constants: NFTYPE-1 = 5; NDDIV-1 = 6. WAVE 0-4; MODE 0-3; SHAPE 0-5. For pages and four-knob assignments, see sections 11-14. Effect CCs are shared; they are not Bank B per-part sends.

## MIDI appendix / 3

Incoming CC values are 0-127 and scaled to the parameter maximum. This table describes the ANALOG engine. Identifiers retain source names to distinguish oscillators/envelopes.

| ID | CC | Display | Raw maximum |
| --- | --- | --- | --- |
| ARP_DIV | 62 | DIV | 6 |
| ARP_OCT | 63 | OCTAVES | 4 |
| ARP_GATE | 65 | GATE | 127 |
| FMORPH | 66 | MORPH | 127 |
| CHO_RATE | 67 | RATE | 127 |
| CHO_DEPTH | 68 | DEPTH | 127 |
| CHO_MIX | 69 | MIX | 127 |
| DLY_TIME | 70 | TIME | NDDIV - 1 |
| DLY_FB | 75 | FEEDBK | 127 |
| DLY_TONE | 76 | TONE | 127 |
| DLY_MIX | 77 | MIX | 127 |
| REV_SIZE | 78 | SIZE | 127 |
| REV_DAMP | 79 | DAMP | 127 |
| REV_PRE | 80 | PRE-DLY | 127 |
| REV_MIX | 81 | MIX | 127 |

Constants: NFTYPE-1 = 5; NDDIV-1 = 6. WAVE 0-4; MODE 0-3; SHAPE 0-5. For pages and four-knob assignments, see sections 11-14. Effect CCs are shared; they are not Bank B per-part sends.

## Updates and USB audio

Already using SMKSYNTH? Export a backup and choose Update in the public installer. Public versions and compatible experimental builds through Endless MIDI A are accepted and the saved bank is preserved. Install is only for first installation from V016 and replaces the bank. The new public identity is SMK-37 Pro_19664 / SMK-37 Elite_19664.

Stereo 16-bit USB audio, 44.1/48 kHz: tested on Mac and on iPhone with AudioShare. Known issue: iPhone video recordings using USB audio may contain clicks or dropouts.

## Links

- [Site](https://4t59m4f784-creator.github.io/SMKSYNTH/?lang=en)
- [Installer](https://4t59m4f784-creator.github.io/SMKSYNTH/install/?lang=en)
- [Simulator](https://4t59m4f784-creator.github.io/SMKSYNTH/simulator/?lang=en)
- [Backup](https://4t59m4f784-creator.github.io/SMKSYNTH/backup/?lang=en)

[GitHub](https://github.com/4t59m4f784-creator/SMKSYNTH)
